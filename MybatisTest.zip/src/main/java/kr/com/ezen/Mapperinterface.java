package kr.com.ezen;

public interface Mapperinterface {
		
	int insertMember(MemberVO vo);
}

